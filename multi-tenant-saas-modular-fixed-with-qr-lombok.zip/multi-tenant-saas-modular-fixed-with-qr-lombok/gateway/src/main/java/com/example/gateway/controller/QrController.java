package com.example.gateway.controller;

import com.example.core.service.QrService;
import com.example.gateway.filter.TenantContextHolder;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/qr")
@RequiredArgsConstructor
public class QrController {

    private final ApplicationContext context;

    @GetMapping("/generate")
    public String generateQr() {
        String tenantId = TenantContextHolder.getTenantId();
        QrService qrService = (QrService) context.getBean(tenantId + "Qr");
        return qrService.generateQrCode();
    }
}
