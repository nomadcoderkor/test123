package com.example.gateway.controller;

import com.example.core.service.BusService;
import com.example.gateway.filter.TenantContextHolder;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bus")
@RequiredArgsConstructor
public class BusController {

    private final ApplicationContext context;

    @GetMapping("/list")
    public List<String> getSchedule() {
        String tenantId = TenantContextHolder.getTenantId();
        BusService service = (BusService) context.getBean(tenantId);
        return service.getBusSchedule();
    }
}
