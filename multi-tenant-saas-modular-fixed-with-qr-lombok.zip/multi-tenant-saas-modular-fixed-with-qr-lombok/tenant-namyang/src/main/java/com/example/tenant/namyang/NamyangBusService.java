package com.example.tenant.namyang;

import com.example.core.service.BusService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("namyang")
public class NamyangBusService implements BusService {
    public List<String> getBusSchedule() {
        return List.of("Namyang - 07:30", "Namyang - 17:30");
    }
}
// Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ0ZXN0LXVzZXIiLCJ0ZW5hbnRJZCI6InBhbmd5byIsImV4cCI6MTc1MTk0MDY0Mn0.RX1VFyMJ3E63ZiEcXNxTC8fc7Rh0LTaUaoMyEpVjGYQ