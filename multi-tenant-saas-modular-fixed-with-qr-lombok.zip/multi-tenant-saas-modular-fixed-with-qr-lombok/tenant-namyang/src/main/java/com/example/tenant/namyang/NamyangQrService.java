package com.example.tenant.namyang;

import com.example.core.service.QrService;
import org.springframework.stereotype.Service;

@Service("namyangQr")
public class NamyangQrService implements QrService {
    @Override
    public String generateQrCode() {
        return "QR-NAMYANG-67890";
    }
}
