package com.example.core.service;

import java.util.List;

public interface BusService {
    List<String> getBusSchedule();
}
