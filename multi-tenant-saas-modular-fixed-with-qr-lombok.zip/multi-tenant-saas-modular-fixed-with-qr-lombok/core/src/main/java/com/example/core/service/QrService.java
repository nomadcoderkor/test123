package com.example.core.service;

public interface QrService {
    String generateQrCode();
}
