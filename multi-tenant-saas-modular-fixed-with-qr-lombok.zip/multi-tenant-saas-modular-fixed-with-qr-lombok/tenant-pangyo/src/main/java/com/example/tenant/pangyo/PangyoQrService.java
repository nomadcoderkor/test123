package com.example.tenant.pangyo;

import com.example.core.service.QrService;
import org.springframework.stereotype.Service;

@Service("pangyoQr")
public class PangyoQrService implements QrService {
    @Override
    public String generateQrCode() {
        return "QR-PANGYO-12345";
    }
}
