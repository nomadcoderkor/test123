package com.example.tenant.pangyo;

import com.example.core.service.BusService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("pangyo")
public class PangyoBusService implements BusService {
    public List<String> getBusSchedule() {
        return List.of("Pangyo - 08:00", "Pangyo - 18:00");
    }
}
